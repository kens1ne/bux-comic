export default [
  {
    id: "action",
    name: "Action",
  },
  {
    id: "adult",
    name: "Adult",
  },
  {
    id: "adventure",
    name: "Adventure",
  },
  {
    id: "bl-webtoon",
    name: "BL",
  },
  {
    id: "boys-love",
    name: "Boys love",
  },
  {
    id: "comedy",
    name: "Comedy",
  },
  {
    id: "complete",
    name: "Complete",
  },
  {
    id: "cooking",
    name: "Cooking",
  },
  {
    id: "doujinshi",
    name: "Doujinshi",
  },
  {
    id: "drama",
    name: "Drama",
  },
  {
    id: "ecchi",
    name: "Ecchi",
  },
  {
    id: "fantasy",
    name: "Fantasy",
  },
  {
    id: "girls-love",
    name: "Girls love",
  },
  {
    id: "gossip",
    name: "Gossip",
  },
  {
    id: "harem",
    name: "Harem",
  },
  {
    id: "hentai",
    name: "Hentai",
  },
  {
    id: "historical",
    name: "Historical",
  },
  {
    id: "horror",
    name: "Horror",
  },
  {
    id: "isekai",
    name: "Isekai",
  },
  {
    id: "japanese",
    name: "Japanese",
  },
  {
    id: "josei",
    name: "Josei",
  },
  {
    id: "manga",
    name: "Manga",
  },
  {
    id: "manga-hentai",
    name: "Manga hentai",
  },
  {
    id: "manhua",
    name: "Manhua",
  },
  {
    id: "manhwa-hentai-002",
    name: "Manhwa",
  },
  {
    id: "martial-arts",
    name: "Martial Arts",
  },
  {
    id: "mature",
    name: "Mature",
  },
  {
    id: "mecha",
    name: "Mecha",
  },
  {
    id: "medical",
    name: "Medical",
  },
  {
    id: "mystery",
    name: "Mystery",
  },
  {
    id: "one-shot",
    name: "One shot",
  },
  {
    id: "porn-comic",
    name: "porn comic",
  },
  {
    id: "romance",
    name: "Romance",
  },
  {
    id: "school-life-manhwa-hentai-001",
    name: "School life",
  },
  {
    id: "sci-fi",
    name: "Sci-fi",
  },
  {
    id: "seinen",
    name: "Seinen",
  },
  {
    id: "shoujo",
    name: "Shoujo",
  },
  {
    id: "shoujo-ai",
    name: "Shoujo Ai",
  },
  {
    id: "shounen",
    name: "Shounen",
  },
  {
    id: "shounen-ai",
    name: "Shounen Ai",
  },
  {
    id: "slice-of-life",
    name: "Slice of Life",
  },
  {
    id: "smut",
    name: "Smut",
  },
  {
    id: "sports",
    name: "Sports",
  },
  {
    id: "supernatural",
    name: "Supernatural",
  },
  {
    id: "thriller",
    name: "Thriller",
  },
  {
    id: "tl",
    name: "TL",
  },
  {
    id: "tragedy",
    name: "Tragedy",
  },
  {
    id: "webtoon",
    name: "Webtoon",
  },
  {
    id: "webtoons",
    name: "Webtoons",
  },
  {
    id: "yaoi",
    name: "Yaoi",
  },
  {
    id: "yuri",
    name: "Yuri",
  },
];
