import Header from "@/components/layout/Header";
import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import { virtualArray } from "@/utils/VirtualArray";
import Comic from "@/components/ComicCard";
import { AiOutlineArrowRight } from "react-icons/ai";
import axios from "axios";
import Pagination from "@/components/Pagination";
import Footer from "@/components/layout/Footer";

const getLatestUpdateByPage = async (page) => {
  return await fetch(`https://api.manhwaco.com/latest?page=` + page)
    .then((res) => res.json())
    .then((res) => res);
};

export const getStaticProps = async ({ params }) => {
  const page = params?.page || 1;
  const { comics: comics, total_pages: totalPages } =
    await getLatestUpdateByPage(page);

  return {
    props: {
      comics,
      totalPages,
    },
    revalidate: 60 * 1,
  };
};

const Page = (props) => {
  const router = useRouter();
  const page = Number(router.query.page || 1);
  const comics = props.comics;
  const title =
    "Last Update - Page " + page + " | Read Manhwa, Adult Manhwa, Manhwaco.Com";
  const totalPages = props.totalPages;

  return (
    <>
      <Head>
        <title>{title}</title>
        <meta property="og:locale" content="en_US" />
        <meta property="og:type" content="website" />
        <meta
          property="og:title"
          content="Read Manhwa, Manhwa Hentai, Manhwa 18, Hentai Manga, Hentai Comics, E
          hentai, Porn Comics | ManhwaCo.Com"
        />
        <meta property="og:image" content="https://manhwaco.com/manhwaco.jpg" />
        <meta
          property="og:description"
          content="Read Free Online Manhwa, Manhwa 18, Hentai Comics, Webtoon Hentai, Manhua Hentai, Manga Hentai, Adult Manhwa, Hentai Webtoon, Manhwaco. Along with brand new series! Updated Daily!"
        />
        <meta property="og:url" content="https://manhwaco.com/" />
        <meta
          property="og:site_name"
          content="Read Manhwa, Manhwa hentai, Adult Manhwa, Manhwa 18, Hentai Webtoon, Hentai Manhwa, Hentai Manga, Hentai Comics"
        />
      </Head>
      <Header />
      <main>
        <div className="latest-update py-3 px-2 bg-white">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-xl my-2 font-bold">
              Latest update - Page {page}
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-5">
              {comics?.map((item, index) => {
                return <Comic key={index} data={item} />;
              })}
            </div>
            <Pagination
              path={`page`}
              currentPage={page}
              totalPages={totalPages}
            />
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
};
export async function getStaticPaths() {
  return {
    paths: [],
    fallback: "blocking",
  };
}

export default Page;
